package com.demo.beans.request;

public class UpdateClassesRequestDTO {
	 private Integer totalClassesTakes;
	    private Long classId;

	    // Getters and Setters
	    public Integer getTotalClassesTakes() {
	        return totalClassesTakes;
	    }

	    public void setTotalClassesTakes(Integer totalClassesTakes) {
	        this.totalClassesTakes = totalClassesTakes;
	    }

	    public Long getClassId() {
	        return classId;
	    }

	    public void setClassId(Long classId) {
	        this.classId = classId;
	    }

}
