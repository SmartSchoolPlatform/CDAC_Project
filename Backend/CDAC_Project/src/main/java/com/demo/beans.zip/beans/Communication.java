package com.demo.beans;

import javax.persistence.*;

@Entity
@Table(name = "Communication")
public class Communication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long messageId;

    @ManyToOne
    @JoinColumn(name = "parent_id")
    private Parent parent;

    private String message;

	public Communication() {
		super();
	}

	public Communication(Parent parent, String message) {
		super();
		this.parent = parent;
		this.message = message;
	}

	public Communication(Long messageId, Parent parent, String message) {
		super();
		this.messageId = messageId;
		this.parent = parent;
		this.message = message;
	}

	public Long getComplaintId() {
		return messageId;
	}

	public void setComplaintId(Long messageId) {
		this.messageId = messageId;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "Complaints [messageId=" + messageId + ", parent=" + parent + ", message="
				+ message + "]";
	}

    
}
