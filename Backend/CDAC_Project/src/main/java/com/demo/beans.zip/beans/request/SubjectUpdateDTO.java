package com.demo.beans.request;



public class SubjectUpdateDTO {
    private Long subjectId;
    private Long staffId;

    // Getters and setters
    public Long getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Long subjectId) {
        this.subjectId = subjectId;
    }

    public Long getStaffId() {
        return staffId;
    }

    public void setStaffId(Long staffId) {
        this.staffId = staffId;
    }
}
