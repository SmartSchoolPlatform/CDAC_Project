package com.demo.beans;

import javax.persistence.*;

@Entity
@Table(name = "Exams")
public class Exams {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long examId;
    
    private String examName;
    
    @ManyToOne
    @JoinColumn(name = "subject_id")
    private Subjects subjects;

    @ManyToOne
    @JoinColumn(name = "class_id")
    private Classes classes;

	public Exams() {
		super();
	}
	
	

	public Exams(String examName, Subjects subjects, Classes classes) {
		super();
		this.examName = examName;
		this.subjects = subjects;
		this.classes = classes;
	}



	public Exams(Long examId, String examName, Subjects subjects, Classes classes) {
		super();
		this.examId = examId;
		this.examName = examName;
		this.subjects = subjects;
		this.classes = classes;
	}



	public Long getExamId() {
		return examId;
	}



	public void setExamId(Long examId) {
		this.examId = examId;
	}



	public String getExamName() {
        return examName;
    }

    public void setExamName(String examName) {
        this.examName = examName;
    }

    public Subjects getSubjects() {
        return subjects;
    }

    public void setSubjects(Subjects subjects) {
        this.subjects = subjects;
    }

    public Classes getClasses() {
        return classes;
    }

    public void setClasses(Classes classes) {
        this.classes = classes;
    }

    @Override
    public String toString() {
        return "Exams [examId=" + ", examName=" + examName + ", examDate=" + ", subjects="
                + subjects + ", classes=" + classes + "]";
    }
}
